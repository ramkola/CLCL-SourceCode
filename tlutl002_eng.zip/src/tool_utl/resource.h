//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by tool_utl.rc
//
#define IDD_DIALOG_DATE_TIME_FORMAT     101
#define IDD_DIALOG_QUOTE                102
#define IDD_DIALOG_JOIN_TEXT            103
#define IDD_DIALOG_MULTI_SAVE           104
#define IDC_COMBO_DATE                  1002
#define IDC_COMBO_TIME                  1003
#define IDC_EDIT_QUOTE_CHAR             1003
#define IDC_CHECK_SHOW                  1004
#define IDC_BUTTON1                     1005
#define IDC_BUTTON_SELECT_PATH          1005
#define IDC_CHECK_ADD_RETURN            1006
#define IDC_EDIT_PATH                   1007
#define IDC_COMBO_FORMAT                1008
#define IDC_EDIT_FILE_NAME              1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
