/*
 * CLCLSet
 *
 * SelectIcon.h
 *
 * Copyright (C) 1996-2019 by Ohno Tomoaki. All rights reserved.
 *		https://www.nakka.com/
 *		nakka@nakka.com
 */

#ifndef _INC_SELECTICON_H
#define _INC_SELECTICON_H

/* Include Files */

/* Define */

/* Struct */

/* Function Prototypes */
int select_icon(const HINSTANCE hInst, const HWND hWnd, TCHAR *path, const int index);

#endif
/* End of source */
