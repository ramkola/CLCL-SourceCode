/*
 * CLCLSet
 *
 * SetSendkey.h
 *
 * Copyright (C) 1996-2019 by Ohno Tomoaki. All rights reserved.
 *		https://www.nakka.com/
 *		nakka@nakka.com
 */

#ifndef _INC_SETSENDKEY_H
#define _INC_SETSENDKEY_H

/* Include Files */

/* Define */

/* Struct */

/* Function Prototypes */
BOOL CALLBACK set_sendkey_proc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

#endif
/* End of source */
