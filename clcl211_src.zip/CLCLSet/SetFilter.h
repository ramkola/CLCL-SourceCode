/*
 * CLCLSet
 *
 * SetFilter.h
 *
 * Copyright (C) 1996-2019 by Ohno Tomoaki. All rights reserved.
 *		https://www.nakka.com/
 *		nakka@nakka.com
 */

#ifndef _INC_SETFILTER_H
#define _INC_SETFILTER_H

/* Include Files */

/* Define */

/* Struct */

/* Function Prototypes */
BOOL CALLBACK set_filter_proc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

#endif
/* End of source */
