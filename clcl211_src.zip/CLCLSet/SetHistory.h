/*
 * CLCLSet
 *
 * SetHistory.h
 *
 * Copyright (C) 1996-2019 by Ohno Tomoaki. All rights reserved.
 *		https://www.nakka.com/
 *		nakka@nakka.com
 */

#ifndef _INC_SETHISTORY_H
#define _INC_SETHISTORY_H

/* Include Files */

/* Define */

/* Struct */

/* Function Prototypes */
BOOL CALLBACK set_histroy_proc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

#endif
/* End of source */
