CLCL Ver 2.1.1
--

CLCL is clipboard caching utility.

- All clipboard formats are supported.
- Template can be registered.
- Pop-up menu is displayed by "Alt+C."
- Menu can be customized.
- Item is paste automatically.
- Picture is displayed on a menu.
- Tool tip is displayed on a menu.
- The format to leave and the format to save can be set up.
- The ignored window can be set up.
- The paste key for every window can be set up.
- Function is extensible with plug-in.
- Unicode
- Freeware

--
Copyright (C) 1996-2019 by Ohno Tomoaki. All rights reserved.
	https://www.nakka.com/

2019/12/17
