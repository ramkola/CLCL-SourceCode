/*
 * CLCL
 *
 * History.h
 *
 * Copyright (C) 1996-2019 by Ohno Tomoaki. All rights reserved.
 *		https://www.nakka.com/
 *		nakka@nakka.com
 */

#ifndef _INC_HISTORY_H
#define _INC_HISTORY_H

/* Include Files */

/* Define */

/* Struct */

/* Function Prototypes */
BOOL history_add(DATA_INFO **root, DATA_INFO *new_item, const BOOL overlap_check);

#endif
/* End of source */
